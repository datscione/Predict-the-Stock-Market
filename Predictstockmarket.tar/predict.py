import pandas as pd

df = pd.read_csv('sphist.csv')
 
df['Date'] = pd.to_datetime(df['Date'])


from datetime import datetime

df['Date'] > datetime(year=2015, month=4, day=1)

df.sort_values('Date', ascending=True, inplace=True)

df = df.set_index('Date')
df['five_day_avg'] = df['Close'].rolling(5).mean()

df['five_day_avg'] = df['five_day_avg'].shift(periods=1) #shifts index forward for this column by 1. Calc rolling avg only using previous 5 days
print(df.head(10))

df['five_day_stddev'] = df['Close'].rolling(5).std()

df['ratio_365_five_day_stddev'] = df['five_day_stddev'] / df['Close'].rolling(365).std()
df['five_day_stddev'] = df['five_day_stddev'].shift(periods=1)
df['ratio_365_five_day_stddev'] = df['ratio_365_five_day_stddev'].shift(periods=1)
print(df.head(10))
print(df.iloc[364:370])
df.dropna(axis=0, inplace=True)
print(df.iloc[364:370])

df.reset_index(inplace=True) #Date becomes a series in df

train = df[df["Date"] < datetime(year=2013, month=1, day=1)]

test = df[df["Date"] >= datetime(year=2013, month=1, day=1)]

from sklearn.linear_model import LinearRegression

lr=LinearRegression()
y_train = train['Close']
x_train = train[['five_day_avg','five_day_stddev', 'ratio_365_five_day_stddev']]  #features
y_test = test['Close']
x_test = test[['five_day_avg','five_day_stddev', 'ratio_365_five_day_stddev']]  #features


lr.fit(x_train, y_train)
y_hat = lr.predict(x_test) #giving features that will be used to predict target, what we don't have data for yet
mae = abs(y_hat - y_test).mean()
print(mae)